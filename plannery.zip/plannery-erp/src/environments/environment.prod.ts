export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyC-yKYGEoUYvGyPCXEnKiyxz4aUolhYOv0',
    authDomain: 'plannery-erp.firebaseapp.com',
    projectId: 'plannery-erp',
    storageBucket: 'plannery-erp.appspot.com',
    messagingSenderId: '280968211876',
    appId: '1:280968211876:web:dcc52292890c921521a531',
  },
};
